sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("RTETOPDF.controller.View1", {

		onChange: function() {
			//this.getView().byId("RE2").setValue(this.getView().byId("RE1").getValue());
			this._injectHTMlBody(this.getView().byId("RE1").getValue());
			/*var base64EncodedPDF = "SGVsbG8="; // the encoded string
			var decodedPdfContent = atob(base64EncodedPDF);
			var byteArray = new Uint8Array(decodedPdfContent.length);
			for (var i = 0; i < decodedPdfContent.length; i++) {
				byteArray[i] = decodedPdfContent.charCodeAt(i);
			}
			var blob = new Blob([byteArray.buffer], {
				type: 'application/pdf'
			});
			var _pdfurl = URL.createObjectURL(blob);
			if (!this._PDFViewer) {
				this._PDFViewer = new sap.m.PDFViewer({
					width: "auto",
					source: _pdfurl // my blob url
				});
				jQuery.sap.addUrlWhitelist("blob"); // register blob url as whitelist
			}
			this._PDFViewer.downloadPDF = function() {
				File.save(
					byteArray.buffer,
					"Hello_UI5",
					"pdf",
					"application/pdf"
				);
			};
			this._PDFViewer.open();*/
		},

		_injectHTMlBody: function(sEmailTemplate) {
			var iframe = document.getElementById('ytplayer');
			var iframedoc = iframe.document;
			if (iframe.contentDocument)
				iframedoc = iframe.contentDocument;
			else if (iframe.contentWindow)
				iframedoc = iframe.contentWindow.document;
			if (iframedoc) {
				// Put the content in the iframe
				iframedoc.write(sEmailTemplate);
			}

			var pdf = new jsPDF('p', 'pt', 'A4');

			// source can be HTML-formatted string, or a reference
			// to an actual DOM element from which the text will be scraped.
			var source =sEmailTemplate

			// we support special element handlers. Register them with jQuery-style 
			// ID selector for either ID or node name. ("#iAmID", "div", "span" etc.)
			// There is no support for any other type of selectors 
			// (class, of compound) at this time.
		/*	specialElementHandlers = {
				// element with id of "bypass" - jQuery style selector
				'div': function(element, renderer) {
					// true = "handled elsewhere, bypass text extraction"
					return true
				}
			}*/

			// all coords and widths are in jsPDF instance's declared units
			// 'inches' in this case
			pdf.fromHTML(
				source // HTML string or DOM elem ref.
				, 0.5 // x coord
				, 0.5 // y coord
				, {
					'width': 7.5 // max width of content on PDF
				}
			)

			pdf.save('Test.pdf');
		},

	});
});